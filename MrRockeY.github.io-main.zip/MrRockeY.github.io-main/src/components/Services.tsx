
import { 
  Code, 
  Layout, 
  Image, 
  FileSpreadsheet, 
  LineChart,
  ChevronRight
} from 'lucide-react';

const ServiceCard = ({ 
  icon: Icon, 
  title, 
  description,
  features
}: { 
  icon: any, 
  title: string, 
  description: string,
  features: string[]
}) => {
  return (
    <div className="bg-white dark:bg-dark-card p-8 rounded-2xl shadow-md card-hover h-full flex flex-col">
      <div className="p-4 rounded-xl bg-brand-blue/10 text-brand-blue dark:bg-brand-blue/20 dark:text-brand-neon w-fit mb-6">
        <Icon size={32} />
      </div>
      
      <h3 className="text-2xl font-bold mb-4">{title}</h3>
      <p className="text-gray-600 dark:text-gray-400 mb-6">{description}</p>
      
      <div className="mt-auto">
        <h4 className="font-semibold text-sm uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-3">
          What's included:
        </h4>
        
        <ul className="space-y-2">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start gap-2">
              <ChevronRight className="text-brand-blue dark:text-brand-neon shrink-0 mt-1" size={16} />
              <span className="text-gray-600 dark:text-gray-300">{feature}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

const Services = () => {
  const services = [
    {
      icon: Code,
      title: "Web Development",
      description: "Modern, responsive websites and web applications that perform flawlessly across all devices.",
      features: [
        "Frontend Development (React, Tailwind CSS)",
        "Responsive and Interactive Websites",
        "SEO and Performance Optimization",
        "API Integration and Development"
      ]
    },
    {
      icon: Layout,
      title: "UI/UX Design",
      description: "Intuitive user experiences and stunning interfaces that keep users engaged and satisfied.",
      features: [
        "Prototyping and Wireframing",
        "User Experience Research",
        "Aesthetic and Responsive Interfaces",
        "Design System Development"
      ]
    },
    {
      icon: Image,
      title: "Graphic & Thumbnail Design",
      description: "Eye-catching visuals that grab attention and effectively communicate your message.",
      features: [
        "High-Impact YouTube Thumbnails",
        "Social Media Graphics",
        "Branding and Logo Design",
        "Marketing Collateral"
      ]
    },
    {
      icon: FileSpreadsheet,
      title: "Advanced Excel Solutions",
      description: "Powerful spreadsheet tools and systems that streamline your data workflows and analysis.",
      features: [
        "Data Processing and Analysis",
        "Interactive Dashboards",
        "Automated Reports",
        "Custom Formulas and Macros"
      ]
    },
    {
      icon: LineChart,
      title: "Custom Dashboards",
      description: "Insightful and interactive dashboards that visualize your data for better decision making.",
      features: [
        "Wedding Planner Dashboards",
        "Admin and Management Dashboards",
        "Real-time Data Visualization",
        "Interactive Analytics Interfaces"
      ]
    }
  ];
  
  return (
    <section id="services" className="section-padding bg-gray-50 dark:bg-dark-bg/50">
      <div className="container mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-16 animate-fade-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            My <span className="text-gradient">Services</span>
          </h2>
          <p className="text-gray-600 dark:text-gray-400 text-lg">
            I provide comprehensive solutions tailored to your specific needs and goals.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
              <ServiceCard 
                icon={service.icon} 
                title={service.title} 
                description={service.description}
                features={service.features}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
