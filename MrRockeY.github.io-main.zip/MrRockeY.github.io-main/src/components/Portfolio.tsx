
import { useState } from 'react';
import { ExternalLink, Code, Layers } from 'lucide-react';

type Project = {
  id: number;
  title: string;
  description: string;
  category: string;
  image: string;
  techStack: string[];
  demoLink?: string;
};

const Portfolio = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  
  const projects: Project[] = [
    {
      id: 1,
      title: "Modern E-commerce Website",
      description: "A responsive e-commerce platform with product filtering, cart functionality, and secure checkout.",
      category: "web",
      image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?auto=format&fit=crop&w=800&q=80",
      techStack: ["React", "Node.js", "Tailwind CSS", "Stripe API"],
      demoLink: "#"
    },
    {
      id: 2,
      title: "YouTube Channel Branding",
      description: "Complete branding package including thumbnails, channel art, and profile picture design.",
      category: "graphic",
      image: "https://images.unsplash.com/photo-1605810230434-7631ac76ec81?auto=format&fit=crop&w=800&q=80",
      techStack: ["Photoshop", "Illustrator", "Canva"],
      demoLink: "#"
    },
    {
      id: 3,
      title: "Wedding Planner Dashboard",
      description: "A comprehensive dashboard for wedding planners to manage events, clients, and budgets.",
      category: "dashboard",
      image: "https://images.unsplash.com/photo-1481891681446-41a57802171e?auto=format&fit=crop&w=800&q=80",
      techStack: ["React", "Firebase", "Chart.js", "Tailwind CSS"],
      demoLink: "#"
    },
    {
      id: 4,
      title: "Budget Tracker Application",
      description: "An Excel-based budget tracking solution with custom formulas and visualizations.",
      category: "excel",
      image: "https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7?auto=format&fit=crop&w=800&q=80",
      techStack: ["Excel", "VBA", "PowerPivot", "DAX"],
      demoLink: "#"
    },
    {
      id: 5,
      title: "Course Platform UI Design",
      description: "User-friendly interface design for an online learning platform with accessibility features.",
      category: "ui",
      image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80",
      techStack: ["Figma", "Adobe XD", "Sketch"],
      demoLink: "#"
    },
    {
      id: 6,
      title: "Viral YouTube Thumbnails",
      description: "Eye-catching thumbnail designs that increased click-through rates by 45%.",
      category: "graphic",
      image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80",
      techStack: ["Photoshop", "Canva"],
      demoLink: "#"
    }
  ];
  
  const categories = [
    { id: 'all', label: 'All Projects' },
    { id: 'web', label: 'Web Development' },
    { id: 'graphic', label: 'Graphic Design' },
    { id: 'ui', label: 'UI/UX Design' },
    { id: 'dashboard', label: 'Dashboards' },
    { id: 'excel', label: 'Excel Projects' }
  ];
  
  const filteredProjects = activeCategory === 'all' 
    ? projects 
    : projects.filter(project => project.category === activeCategory);
  
  return (
    <section id="portfolio" className="section-padding bg-white dark:bg-dark-bg">
      <div className="container mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-12 animate-fade-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Featured <span className="text-gradient">Projects</span>
          </h2>
          <p className="text-gray-600 dark:text-gray-400 text-lg">
            Browse through a selection of my best work across different domains.
          </p>
        </div>
        
        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-3 mb-10 animate-fade-in">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                activeCategory === category.id
                  ? 'bg-brand-blue text-white'
                  : 'bg-gray-100 dark:bg-dark-card text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>
        
        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <div 
              key={project.id} 
              className="group bg-white dark:bg-dark-card rounded-xl overflow-hidden shadow-md card-hover animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="relative h-60 overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                  <div className="text-white">
                    <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {project.techStack.map((tech, idx) => (
                        <span key={idx} className="px-2 py-1 text-xs rounded bg-white/20 backdrop-blur-sm">
                          {tech}
                        </span>
                      ))}
                    </div>
                    {project.demoLink && (
                      <a 
                        href={project.demoLink} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-brand-neon hover:underline text-sm"
                      >
                        View Project <ExternalLink size={14} />
                      </a>
                    )}
                  </div>
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-medium px-3 py-1 rounded-full bg-brand-blue/10 text-brand-blue dark:bg-brand-blue/20 dark:text-brand-neon">
                    {categories.find(cat => cat.id === project.category)?.label}
                  </span>
                  <div className="flex gap-2">
                    <span className="p-1.5 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300">
                      <Code size={14} />
                    </span>
                    <span className="p-1.5 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300">
                      <Layers size={14} />
                    </span>
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2 text-gray-800 dark:text-white group-hover:text-brand-blue dark:group-hover:text-brand-neon transition-colors">
                  {project.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
