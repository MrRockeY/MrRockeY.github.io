
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="min-h-screen relative overflow-hidden flex items-center">
      {/* Animated background elements */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 left-10 w-60 h-60 rounded-full hero-gradient opacity-20 blur-3xl animate-pulse-glow"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 rounded-full hero-gradient opacity-20 blur-3xl animate-pulse-glow animate-delay-300"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full hero-gradient opacity-10 blur-3xl animate-rotate-slow"></div>
      </div>

      <div className="container mx-auto px-6 md:px-12 pt-24 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-12">
          <div className="w-full md:w-1/2 space-y-6 animate-fade-in">
            <div className="inline-block px-4 py-2 rounded-full bg-brand-blue/10 text-brand-blue dark:bg-brand-blue/20 dark:text-brand-neon font-medium animate-fade-in">
              <span className="animate-bounce-subtle inline-block">👋</span> Hello, I'm
            </div>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight animate-fade-in animate-delay-200">
              <span className="text-gradient">Mr. Rocky</span>
            </h1>
            
            <h2 className="text-xl md:text-3xl text-gray-600 dark:text-gray-300 font-light animate-fade-in animate-delay-300">
              Crafting Digital Experiences with
              <span className="relative">
                <span className="ml-2 font-semibold relative">
                  Creativity
                  <span className="absolute -bottom-1 left-0 w-full h-1 bg-brand-gold rounded-full"></span>
                </span>
              </span> and
              <span className="relative">
                <span className="ml-2 font-semibold relative">
                  Precision
                  <span className="absolute -bottom-1 left-0 w-full h-1 bg-brand-neon rounded-full"></span>
                </span>
              </span>
            </h2>
            
            <p className="text-gray-600 dark:text-gray-400 text-lg md:text-xl max-w-lg animate-fade-in animate-delay-400">
              From web development to visual storytelling, I build powerful solutions that captivate and engage.
            </p>
            
            <div className="flex flex-wrap gap-4 animate-fade-in animate-delay-500">
              <button 
                className="btn-primary flex items-center gap-2"
                onClick={() => scrollToSection('portfolio')}
              >
                Explore My Work <ArrowRight size={16} />
              </button>
              
              <button 
                className="btn-secondary flex items-center gap-2"
                onClick={() => scrollToSection('contact')}
              >
                Hire Me <ArrowRight size={16} />
              </button>
            </div>
          </div>
          
          <div className="w-full md:w-1/2 flex justify-center animate-fade-in-right">
            <div className="relative">
              {/* Hero 3D element or image would go here */}
              <div className="relative w-64 h-64 md:w-80 md:h-80 hero-gradient rounded-full flex items-center justify-center overflow-hidden">
                <span className="text-white text-5xl font-bold animate-bounce-subtle">MR</span>
                
                {/* Orbiting elements */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-4 h-4 bg-brand-gold rounded-full animate-rotate-slow" style={{ transformOrigin: 'center 150px' }}></div>
                <div className="absolute top-1/2 right-0 -translate-y-1/2 w-6 h-6 bg-brand-neon rounded-full animate-rotate-slow" style={{ transformOrigin: '-110px center', animationDelay: '1s' }}></div>
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-5 h-5 bg-white rounded-full animate-rotate-slow" style={{ transformOrigin: 'center -130px', animationDelay: '2s' }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
