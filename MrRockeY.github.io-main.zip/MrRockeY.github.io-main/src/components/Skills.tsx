
import { useState } from 'react';
import { Code, Layout, Image, Database, FileSpreadsheet, LineChart } from 'lucide-react';

const SkillCard = ({ 
  icon: Icon, 
  title, 
  description, 
  level 
}: { 
  icon: any, 
  title: string, 
  description: string, 
  level: number
}) => {
  const [isHovered, setIsHovered] = useState(false);
  
  return (
    <div 
      className="bg-white dark:bg-dark-card p-6 rounded-2xl shadow-md card-hover"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex items-start gap-4">
        <div className="p-3 rounded-lg bg-brand-blue/10 text-brand-blue dark:bg-brand-blue/20 dark:text-brand-neon">
          <Icon size={24} />
        </div>
        
        <div className="flex-1">
          <h3 className="text-xl font-bold mb-2">{title}</h3>
          
          <div className="skill-progress-bar mb-2">
            <div 
              className="skill-progress-fill transition-all duration-1000 ease-out" 
              style={{ width: isHovered ? `${level}%` : '0%' }}
            ></div>
          </div>
          
          <p className="text-gray-600 dark:text-gray-400">{description}</p>
        </div>
      </div>
    </div>
  );
};

const Skills = () => {
  const skills = [
    {
      icon: Code,
      title: "Web Development",
      description: "JavaScript, HTML, CSS, React, Tailwind CSS, responsive design, and modern web practices.",
      level: 90
    },
    {
      icon: Layout,
      title: "UI/UX Design",
      description: "Creating intuitive and beautiful interfaces with Figma, Adobe XD, and design thinking principles.",
      level: 85
    },
    {
      icon: Image,
      title: "Graphic Design",
      description: "Photoshop, Illustrator, Canva for compelling visuals and branding materials.",
      level: 80
    },
    {
      icon: Image,
      title: "YouTube Thumbnail Design",
      description: "Eye-catching thumbnails that drive engagement and improve click-through rates.",
      level: 95
    },
    {
      icon: FileSpreadsheet,
      title: "Excel & Data Solutions",
      description: "Advanced formulas, macros, data analysis, and automated reporting solutions.",
      level: 85
    },
    {
      icon: LineChart,
      title: "Dashboard Design",
      description: "Beautiful and functional dashboards for wedding planners, admins, and data visualization.",
      level: 92
    }
  ];
  
  return (
    <section id="skills" className="section-padding bg-gray-50 dark:bg-dark-bg/50">
      <div className="container mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-16 animate-fade-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            My <span className="text-gradient">Expertise</span>
          </h2>
          <p className="text-gray-600 dark:text-gray-400 text-lg">
            With years of experience across multiple disciplines, I've honed my skills to deliver exceptional results in these areas.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map((skill, index) => (
            <div key={index} className="animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
              <SkillCard 
                icon={skill.icon} 
                title={skill.title} 
                description={skill.description} 
                level={skill.level} 
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
