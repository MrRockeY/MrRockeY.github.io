
import { Calendar, ChevronRight, User } from 'lucide-react';

const blogPosts = [
  {
    id: 1,
    title: "Creating High-Converting YouTube Thumbnails: A Complete Guide",
    excerpt: "Learn the psychology and design principles behind thumbnails that drive clicks and engagement for your YouTube channel.",
    category: "Design",
    date: "June 15, 2023",
    author: "Mr. Rocky",
    readTime: "9 min read",
    image: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 2,
    title: "10 Advanced Excel Formulas Every Professional Should Know",
    excerpt: "Power up your spreadsheet skills with these advanced formulas that will save you time and improve your data analysis.",
    category: "Excel",
    date: "May 22, 2023",
    author: "Mr. Rocky",
    readTime: "7 min read",
    image: "https://images.unsplash.com/photo-1607705703571-c5a8695f18f6?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 3,
    title: "Building Responsive Websites with Tailwind CSS",
    excerpt: "A step-by-step guide to creating beautiful, responsive websites using the utility-first approach of Tailwind CSS.",
    category: "Development",
    date: "April 10, 2023",
    author: "Mr. Rocky",
    readTime: "11 min read",
    image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=800&q=80"
  }
];

const Blog = () => {
  return (
    <section id="blog" className="section-padding bg-gray-50 dark:bg-dark-bg/50">
      <div className="container mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-16 animate-fade-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Latest <span className="text-gradient">Articles</span>
          </h2>
          <p className="text-gray-600 dark:text-gray-400 text-lg">
            Insights, tutorials, and expert advice on web development, design, and digital solutions.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <div 
              key={post.id} 
              className="bg-white dark:bg-dark-card rounded-xl overflow-hidden shadow-md card-hover animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="h-48 overflow-hidden">
                <img 
                  src={post.image} 
                  alt={post.title} 
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-xs font-medium px-3 py-1 rounded-full bg-brand-blue/10 text-brand-blue dark:bg-brand-blue/20 dark:text-brand-neon">
                    {post.category}
                  </span>
                  
                  <div className="flex items-center text-gray-500 dark:text-gray-400 text-xs">
                    <Calendar size={12} className="mr-1" />
                    {post.date}
                  </div>
                </div>
                
                <h3 className="text-xl font-bold mb-3 text-gray-800 dark:text-white hover:text-brand-blue dark:hover:text-brand-neon transition-colors">
                  {post.title}
                </h3>
                
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">
                  {post.excerpt}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <User size={14} className="text-gray-500 dark:text-gray-400" />
                    <span className="text-gray-500 dark:text-gray-400 text-xs">{post.author}</span>
                    <span className="text-gray-400 dark:text-gray-500 text-xs">•</span>
                    <span className="text-gray-500 dark:text-gray-400 text-xs">{post.readTime}</span>
                  </div>
                  
                  <a 
                    href="#" 
                    className="inline-flex items-center text-brand-blue dark:text-brand-neon hover:underline text-sm font-medium"
                  >
                    Read More <ChevronRight size={16} />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12 animate-fade-in">
          <a 
            href="#" 
            className="btn-primary inline-flex items-center gap-2"
          >
            View All Articles <ChevronRight size={16} />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Blog;
