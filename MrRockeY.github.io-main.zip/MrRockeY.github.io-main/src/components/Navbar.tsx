
import { useState, useEffect } from 'react';
import { Menu, X, Moon, Sun } from 'lucide-react';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    
    // Check for saved dark mode preference
    const savedDarkMode = localStorage.getItem('darkMode') === 'true';
    setIsDarkMode(savedDarkMode);
    if (savedDarkMode) {
      document.documentElement.classList.add('dark');
    }
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleDarkMode = () => {
    const newDarkMode = !isDarkMode;
    setIsDarkMode(newDarkMode);
    localStorage.setItem('darkMode', newDarkMode.toString());
    
    if (newDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 80,
        behavior: 'smooth'
      });
      setIsMenuOpen(false);
    }
  };

  return (
    <nav 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled 
          ? 'py-3 bg-white/80 dark:bg-dark-bg/80 backdrop-blur-md shadow-md' 
          : 'py-5 bg-transparent'
      }`}
    >
      <div className="container mx-auto px-6 md:px-12 flex justify-between items-center">
        <a 
          className="text-2xl font-bold text-gray-800 dark:text-white"
          href="#"
          onClick={(e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        >
          <span className="text-gradient">Mr. Rocky</span>
        </a>
        
        <div className="hidden md:flex items-center space-x-8">
          <a className="nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('home');}}>Home</a>
          <a className="nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('skills');}}>Skills</a>
          <a className="nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('portfolio');}}>Portfolio</a>
          <a className="nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('services');}}>Services</a>
          <a className="nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('testimonials');}}>Testimonials</a>
          <a className="nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('blog');}}>Blog</a>
          <a className="nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('contact');}}>Contact</a>
          
          <button 
            onClick={toggleDarkMode}
            className="p-2 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 transition-colors"
            aria-label="Toggle dark mode"
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
        
        <div className="md:hidden flex items-center">
          <button 
            onClick={toggleDarkMode}
            className="p-2 mr-2 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200"
            aria-label="Toggle dark mode"
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-2 text-gray-600 dark:text-gray-300 hover:text-brand-blue dark:hover:text-brand-neon"
            aria-label="Open menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 bg-white dark:bg-dark-bg pt-24 px-6 md:hidden animate-fade-in">
          <div className="flex flex-col space-y-6 text-center">
            <a className="text-xl nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('home');}}>Home</a>
            <a className="text-xl nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('skills');}}>Skills</a>
            <a className="text-xl nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('portfolio');}}>Portfolio</a>
            <a className="text-xl nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('services');}}>Services</a>
            <a className="text-xl nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('testimonials');}}>Testimonials</a>
            <a className="text-xl nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('blog');}}>Blog</a>
            <a className="text-xl nav-link" href="#" onClick={(e) => {e.preventDefault(); scrollToSection('contact');}}>Contact</a>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
