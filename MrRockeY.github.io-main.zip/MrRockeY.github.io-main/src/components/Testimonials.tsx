
import { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: "Sarah Johnson",
    role: "Marketing Director",
    company: "Brand Elevation",
    content: "Mr. Rocky took our website from outdated to outstanding. His attention to detail and intuitive design sense transformed our online presence completely. Not only did he deliver an amazing product, but he was a pleasure to work with throughout the process.",
    avatar: "https://randomuser.me/api/portraits/women/1.jpg",
  },
  {
    id: 2,
    name: "David Chen",
    role: "Content Creator",
    company: "YouTube",
    content: "The thumbnails Rocky designed for my channel increased my click-through rate by over 40%. His understanding of what catches viewers' attention is unmatched. I won't work with anyone else for my graphic design needs.",
    avatar: "https://randomuser.me/api/portraits/men/2.jpg",
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    role: "Wedding Planner",
    company: "Dream Day Events",
    content: "The wedding planning dashboard Rocky created has revolutionized how I organize events. It's intuitive, beautiful, and has saved me countless hours of work. My clients are impressed by how smoothly everything runs now.",
    avatar: "https://randomuser.me/api/portraits/women/3.jpg",
  },
  {
    id: 4,
    name: "Michael Thompson",
    role: "Finance Manager",
    company: "Global Analytics",
    content: "Rocky's Excel expertise helped us transform our reporting system. The custom dashboard he built automatically processes our data and visualizes key metrics, saving our team hours each week and providing better insights for decision-making.",
    avatar: "https://randomuser.me/api/portraits/men/4.jpg",
  },
];

const Testimonials = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [direction, setDirection] = useState<'right' | 'left' | null>(null);
  const testimonialRef = useRef<HTMLDivElement>(null);
  
  const nextTestimonial = () => {
    setDirection('right');
    setActiveIndex((prev) => (prev + 1) % testimonials.length);
  };
  
  const prevTestimonial = () => {
    setDirection('left');
    setActiveIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };
  
  useEffect(() => {
    const interval = setInterval(() => {
      nextTestimonial();
    }, 8000);
    
    return () => clearInterval(interval);
  }, []);
  
  const renderTestimonial = (testimonial: typeof testimonials[0], isActive: boolean) => (
    <div 
      className={`bg-white dark:bg-dark-card p-8 rounded-2xl shadow-md h-full flex flex-col transform transition-all duration-500 ${
        isActive 
          ? 'opacity-100 scale-100 translate-x-0' 
          : direction === 'right' 
            ? 'opacity-0 scale-95 translate-x-full absolute' 
            : 'opacity-0 scale-95 -translate-x-full absolute'
      }`}
    >
      <div className="flex items-center gap-4 mb-6">
        <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-brand-blue">
          <img 
            src={testimonial.avatar} 
            alt={testimonial.name} 
            className="w-full h-full object-cover"
          />
        </div>
        
        <div>
          <h3 className="font-bold text-lg">{testimonial.name}</h3>
          <p className="text-gray-600 dark:text-gray-400 text-sm">
            {testimonial.role}, {testimonial.company}
          </p>
        </div>
      </div>
      
      <div className="relative flex-1">
        <Quote className="absolute -top-2 -left-2 text-brand-blue/10 dark:text-brand-blue/20" size={40} />
        <p className="text-gray-600 dark:text-gray-300 italic relative z-10 pl-4">
          "{testimonial.content}"
        </p>
      </div>
    </div>
  );
  
  return (
    <section id="testimonials" className="section-padding bg-white dark:bg-dark-bg">
      <div className="container mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-16 animate-fade-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Client <span className="text-gradient">Testimonials</span>
          </h2>
          <p className="text-gray-600 dark:text-gray-400 text-lg">
            Don't just take my word for it — here's what clients have to say about working with me.
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="relative h-[300px] md:h-[250px]" ref={testimonialRef}>
            {testimonials.map((testimonial, index) => (
              <div key={testimonial.id} className={`absolute inset-0 ${activeIndex === index ? 'z-10' : 'z-0'}`}>
                {renderTestimonial(testimonial, activeIndex === index)}
              </div>
            ))}
          </div>
          
          <div className="flex justify-center gap-3 mt-8">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  activeIndex === index 
                    ? 'bg-brand-blue dark:bg-brand-neon w-10' 
                    : 'bg-gray-300 dark:bg-gray-700'
                }`}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
          
          <div className="flex justify-center gap-4 mt-8">
            <button
              onClick={prevTestimonial}
              className="p-3 rounded-full bg-gray-100 dark:bg-dark-card text-gray-600 dark:text-gray-300 hover:bg-brand-blue hover:text-white dark:hover:bg-brand-blue transition-colors"
              aria-label="Previous testimonial"
            >
              <ChevronLeft size={20} />
            </button>
            
            <button
              onClick={nextTestimonial}
              className="p-3 rounded-full bg-gray-100 dark:bg-dark-card text-gray-600 dark:text-gray-300 hover:bg-brand-blue hover:text-white dark:hover:bg-brand-blue transition-colors"
              aria-label="Next testimonial"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
