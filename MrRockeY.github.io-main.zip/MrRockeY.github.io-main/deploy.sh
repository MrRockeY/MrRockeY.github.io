
#!/usr/bin/env sh

# abort on errors
set -e

# build
npm run build

# navigate into the build output directory
cd dist

# place .nojekyll to bypass Jekyll processing
echo > .nojekyll

git init
git add -A
git commit -m 'deploy'

# Configure Git for GitHub Actions
git config --global user.email "github-actions@github.com"
git config --global user.name "GitHub Actions"

# Use HTTPS instead of SSH for GitHub Actions
git push -f https://${GITHUB_TOKEN}@github.com/MrRockeY/MrRockeY.github.io.git main

cd -
